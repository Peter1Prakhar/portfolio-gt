<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

dynamic_sidebar( 'blog_sidebar' );