<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

/**
 * TGM
 */
require_once GILBER_REQUIRE_DIRECTORY . 'inc/helper/class-tgm-plugin-activation.php';

/**
 * Breadcrumbs
 */
require_once GILBER_REQUIRE_DIRECTORY . 'inc/helper/breadcrumbs/breadcrumbs.php';