<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<a href="<?php the_permalink(); ?>" class="vlt-btn vlt-btn--primary">
	<?php esc_html_e( 'Read More', 'gilber' ); ?>
</a>
<!-- /.vlt-btn -->