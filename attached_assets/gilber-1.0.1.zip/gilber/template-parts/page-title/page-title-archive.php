<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<div class="vlt-page-title">

	<div class="container">

		<h1><?php esc_html_e( 'Archive', 'gilber' ); ?></h1>

		<?php echo gilber_get_breadcrumbs(); ?>

	</div>

</div>
<!-- /.vlt-page-title -->